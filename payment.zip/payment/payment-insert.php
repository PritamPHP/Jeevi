<?php 
// session_start();

// // Include database connection file 
// include_once 'dbConnect.php';

// $name = $_GET['name'];
// $email = $_GET['email'];
// $amount = $_GET['amount'];
// $status = "0";

// $insert = $db->query("INSERT INTO payment(name,email,amount, status) VALUES('".$name."','".$email."','".$amount."','".$status."')");
// $last_id = $db->insert_id;

// $_SESSION['pay_id'] = $last_id;
